/*
Name:           Demo Accounting 1
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  12.0.0
*/

(($ => {
   
	

})).apply( this, [ jQuery ]);
